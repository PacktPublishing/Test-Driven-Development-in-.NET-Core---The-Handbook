﻿using System;

namespace RoomBookingApp.Core.Models
{
    public class RoomBookingRequest : RoomBookingBase
    {
    }
}