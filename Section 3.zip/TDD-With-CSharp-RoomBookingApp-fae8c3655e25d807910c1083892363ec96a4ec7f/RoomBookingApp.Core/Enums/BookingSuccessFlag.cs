﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoomBookingApp.Core.Enums
{
    public enum BookingResultFlag
    {
        Success,
        Failure
    }
}
