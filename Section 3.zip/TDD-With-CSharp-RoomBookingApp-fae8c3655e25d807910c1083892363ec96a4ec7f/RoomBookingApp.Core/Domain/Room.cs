﻿namespace RoomBookingApp.Core.Domain
{
    public class Room
    {
        public int Id { get; set; }
    }
}